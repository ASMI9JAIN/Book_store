//
//  SignUpViewController.swift
//  book
//
//  Created by ASMI iOS Dev on 22/06/21.
//

import UIKit

class SignUpViewController: UIViewController {
    @IBOutlet var phoneField:UITextField!
    @IBOutlet var userField:UITextField!
    @IBOutlet var passField:UITextField!
    @IBOutlet var cPassField:UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func actionsignUp(){
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
